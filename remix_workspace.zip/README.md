# Blockchain Project

## Description
A smart contract for receiving, storing, and withdrawing Ether.

## Usage
1. Open the Remix.
2. Upload the `MyContract.sol' file to the `contracts` folder.
3. Compile and seal the contract.
4. Use the contract functions:
- `- `jetbalance': checking the balance.
   - `withdraw': withdrawal of funds.